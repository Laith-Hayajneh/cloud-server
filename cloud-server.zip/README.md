# cloud-server
#### Execute

Use "Elastic Beanstalk" to Deploy a NodeJS server to an EC2 instance at AWS

This requires 2 parts:

1. An "Environment" (container) for our application to run in
1. The application code itself to be deployed "into" the environment



### Creating an application with the Elastic Beanstalk GUI

- Choose NodeJS as your platform
- Create and upload a .zip file with your application source code
  - Do not include `node_modules` or `package-lock.json`

This will create your application and environment in one step, giving you a full GUI from where you can manage the app
